export class EmpGroup {
    groupId : number;
    groupName: string;
    constructor(grId : number, name : string){
        this.groupId =grId;
        this.groupName=name;
    }
}

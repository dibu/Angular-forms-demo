export class Employee {
    Name : string;
    Address:string;
    Dept : number;
    Group: number;
}

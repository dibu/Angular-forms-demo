import { EmpGroup } from './emp-group.model';

describe('EmpGroup', () => {
  it('should create an instance', () => {
    expect(new EmpGroup()).toBeTruthy();
  });
});

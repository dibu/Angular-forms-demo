export class Dept {
    Id : number;
    Name: string;
    constructor(Id : number, Name: string){
        this.Id=Id;
        this.Name=Name;
    }
}
